#include <stdio.h>
int main()
{
	char* pstr = "abc";
	pstr[0] = 'A';
	printf("pstr[0]=%c\n",pstr[0]);
	return 0;
}
