
int foo(int a)
{
	int b = a;
	return b;
}

int main()
{
	int a = 1;
	foo(a);
	return 0;
}
